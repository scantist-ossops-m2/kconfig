#include "test_qdebugcategory_debug.h"
Q_LOGGING_CATEGORY(CATEGORY_LOG, "log_category")


